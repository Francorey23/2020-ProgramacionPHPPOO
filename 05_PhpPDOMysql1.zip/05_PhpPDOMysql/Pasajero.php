<?php
    require_once("Conexion.php");

    class Pasajero extends Conexion{

        private $pCedula;
        private $pNombres;
        private $pCorreo;
        private $pCelular;
        private $conexion;

        public function __construct()
        {
            $this->conexion = new Conexion();
            $this->conexion = $this->conexion->conect();
        }
        // Proceso para crear el CRUD de Pasajero
        public function InsertarPasajero(string $cedula, string $nombres, string $correo, string $celular)
        {
            $this->pCedula      =   $cedula;
            $this->pNombres     =   $nombres;
            $this->pCorreo      =   $correo;
            $this->pCelular     =   $celular;

            //alistar la instruccion Sql para registrar o cargar datos
            $Sql = "INSERT INTO pasajero(pcedula, pnombres, pcorreo, pcelular) VALUES(?,?,?,?)";
            $insert = $this->conexion->prepare($Sql);
            $arrData = array($this->pCedula, $this->pNombres, $this->pCorreo, $this->pCelular);

            $resInsert  = $insert->execute($arrData);
            $idInsert   = $this->conexion->lastInsertId();
            return $idInsert;
        }

        //  Mostrar los datos de pasajero

        public function getPasajero()
        {
            $Sql = "SELECT pcedula, pnombres, pcorreo, pcelular FROM pasajero";
            $execute = $this->conexion->query($Sql);
            $request = $execute->fetchall(PDO::FETCH_ASSOC);
            return $request;
        }

        

    }//end clase
?>