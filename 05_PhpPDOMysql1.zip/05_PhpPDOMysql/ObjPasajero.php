<?php
        require_once("Pasajero.php");

        $objPasajero = new Pasajero();

       // $insert  = $objPasajero->InsertarPasajero("24", "Mario Santiago", "marios@gamil.com", "311888121");
        //echo $insert;
        
        // Mstar los registros de la tabla pasajero
        $objPasajero = $objPasajero->getPasajero();
        print_r("<pre>");
        print_r($objPasajero);
        print_r("</pre>");

?>